###################################
## module: Mod5DFA.py
## Sally Devitry
## A01980316
###################################

class Mod5DFA:
    def __q0(self, s, pos):
        if len(s) == pos:
            return True
        elif s[pos] == '0':
            return self.__q0(s, pos+1)
        elif s[pos] == '1':
            return self.__q1(s, pos+1)
        else:
            return self.__q5(s, pos+1)

    def __q1(self, s, pos):
        if len(s) == pos:
            return False
        elif s[pos] == '0':
            return self.__q2(s, pos+1)
        elif s[pos] == '1':
            return self.__q3(s, pos+1)
        else:
            return self.__q5(s, pos+1)

    def __q2(self, s, pos):
        if len(s) == pos:
            return False
        elif s[pos] == '0':
            return self.__q4(s, pos+1)
        elif s[pos] == '1':
            return self.__q0(s, pos+1)
        else:
            return self.__q5(s, pos+1)

    def __q3(self, s, pos):
        if len(s) == pos:
            return False
        elif s[pos] == '0':
            return self.__q1(s, pos + 1)
        elif s[pos] == '1':
            return self.__q2(s, pos + 1)
        else:
            return self.__q5(s, pos + 1)

    def __q4(self, s, pos):
        if len(s) == pos:
            return False
        elif s[pos] == '0':
            return self.__q3(s, pos + 1)
        elif s[pos] == '1':
            return self.__q4(s, pos + 1)
        else:
            return self.__q5(s, pos + 1)

    def __q5(self, s, pos):
        if len(s) == pos:
            return False
        elif s[pos] == '0':
            return self.__q5(s, pos + 1)
        elif s[pos] == '1':
            return self.__q5(s, pos + 1)
        else:
            return self.__q5(s, pos + 1)

    def processString(self, s):
        if s[0] == '0':
            return self.__q0(s, 1)
        if s[0] == '1':
            return self.__q1(s, 1)
        else:
            return self.__q3(s, 1)
